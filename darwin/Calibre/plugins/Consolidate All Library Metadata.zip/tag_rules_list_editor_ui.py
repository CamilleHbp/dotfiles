# -*- coding: utf-8 -*-
__license__   = 'GPL v3'
__copyright__ = '2015,2016,2017,2018,2019,2020,2021,2022,2023 DaltonST'
__my_version__ = "2.0.44"  #Qt.core


from qt.core import QtCore, QtGui, QtWidgets

class Ui_TagRulesListEditor(object):
    def setupUi(self, TagRulesListEditor):
        TagRulesListEditor.setObjectName("TagRulesListEditor")
        TagRulesListEditor.resize(397, 335)
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap(I("config.png")), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
        TagRulesListEditor.setWindowIcon(icon)
        self.gridlayout = QtWidgets.QGridLayout(TagRulesListEditor)
        self.gridlayout.setObjectName("gridlayout")
        self.horizontalLayout_11 = QtWidgets.QHBoxLayout()
        self.horizontalLayout_11.setObjectName("horizontalLayout_11")
        self.search_button = QtWidgets.QToolButton(TagRulesListEditor)
        self.search_button.setObjectName("search_button")
        self.gridlayout.addLayout(self.horizontalLayout_11, 0, 1, 1, 1)
        self.verticalLayout_2 = QtWidgets.QVBoxLayout()
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        self.delete_button = QtWidgets.QToolButton(TagRulesListEditor)
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap(I("plus.png")), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
        self.delete_button.setIcon(icon1)
        self.delete_button.setIconSize(QtCore.QSize(32, 32))
        self.delete_button.setObjectName("delete_button")
        self.verticalLayout_2.addWidget(self.delete_button)
        self.rename_button = QtWidgets.QToolButton(TagRulesListEditor)
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap(I("edit_input.png")), QtGui.QIcon.Mode.Normal, QtGui.QIcon.State.Off)
        self.rename_button.setIcon(icon2)
        self.rename_button.setIconSize(QtCore.QSize(2, 2))
        self.rename_button.setObjectName("rename_button")
        self.gridlayout.addLayout(self.verticalLayout_2, 1, 0, 1, 1)
        self.table = QtWidgets.QTableWidget(TagRulesListEditor)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        self.table.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        self.table.setObjectName("table")
        self.table.setColumnCount(0)
        self.table.setRowCount(0)
        self.gridlayout.addWidget(self.table, 1, 1, 1, 1)
        self.buttonBox = QtWidgets.QDialogButtonBox(TagRulesListEditor)
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setCenterButtons(True)
        self.buttonBox.setObjectName("buttonBox")
        self.gridlayout.addWidget(self.buttonBox, 3, 0, 1, 2)

        self.retranslateUi(TagRulesListEditor)
        self.buttonBox.accepted.connect(TagRulesListEditor.accept)
        self.buttonBox.rejected.connect(TagRulesListEditor.reject)
        QtCore.QMetaObject.connectSlotsByName(TagRulesListEditor)

    def retranslateUi(self, TagRulesListEditor):

        TagRulesListEditor.setWindowTitle(_("CALM Easy-Add Tags-to-Purge to Tag Rules Table"))
        self.delete_button.setToolTip(_("Add to Table '_tag_rules' with 'purgetag' set to '1' (purge)."))
        self.delete_button.setText(_("..."))

