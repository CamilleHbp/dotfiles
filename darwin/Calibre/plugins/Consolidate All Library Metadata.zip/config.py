# -*- coding: utf-8 -*-
__license__   = 'GPL v3'
__copyright__ = '2015,2016,2017,2018,2019,2020,2021,2022,2023 DaltonST'
__my_version__ = "2.0.44"  #Qt.core

from qt.core import QWidget, QLabel, QVBoxLayout, QGroupBox, QMargins

from calibre.utils.config import JSONConfig

from polyglot.builtins import unicode_type

# This is where all preferences for this plugin are stored
prefs = JSONConfig('plugins/Consolidate All Library Metadata')

# Set defaults

prefs.defaults['LIBRARY_PATH_03'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_04'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_05'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_06'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_07'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_08'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_09'] = unicode_type("")

prefs.defaults['LIBRARY_PATH_10'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_11'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_12'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_13'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_14'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_15'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_16'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_17'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_18'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_19'] = unicode_type("")

prefs.defaults['LIBRARY_PATH_20'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_21'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_22'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_23'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_24'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_25'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_26'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_27'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_28'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_29'] = unicode_type("")

prefs.defaults['LIBRARY_PATH_30'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_31'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_32'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_33'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_34'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_35'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_36'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_37'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_38'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_39'] = unicode_type("")

prefs.defaults['LIBRARY_PATH_40'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_41'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_42'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_43'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_44'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_45'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_46'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_47'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_48'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_49'] = unicode_type("")

prefs.defaults['LIBRARY_PATH_50'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_51'] = unicode_type("")
prefs.defaults['LIBRARY_PATH_52'] = unicode_type("")

prefs.defaults['LIBRARY_PATH_03_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_04_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_05_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_06_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_07_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_08_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_09_IS_ACTIVE'] = unicode_type("False")

prefs.defaults['LIBRARY_PATH_10_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_11_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_12_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_13_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_14_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_15_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_16_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_17_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_18_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_19_IS_ACTIVE'] = unicode_type("False")

prefs.defaults['LIBRARY_PATH_20_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_21_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_22_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_23_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_24_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_25_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_26_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_27_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_28_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_29_IS_ACTIVE'] = unicode_type("False")

prefs.defaults['LIBRARY_PATH_30_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_31_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_32_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_33_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_34_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_35_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_36_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_37_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_38_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_39_IS_ACTIVE'] = unicode_type("False")

prefs.defaults['LIBRARY_PATH_40_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_41_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_42_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_43_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_44_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_45_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_46_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_47_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_48_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_49_IS_ACTIVE'] = unicode_type("False")

prefs.defaults['LIBRARY_PATH_50_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_51_IS_ACTIVE'] = unicode_type("False")
prefs.defaults['LIBRARY_PATH_52_IS_ACTIVE'] = unicode_type("False")

prefs.defaults['CALM_USER_STATUS'] = unicode_type('UNKNOWN')

prefs.defaults['CALM_TARGET_PARENT_DIRECTORY'] = unicode_type('ZZ:')
prefs.defaults['CALM_TARGET_DB_FULL_PATH'] = unicode_type('ZZ:')
prefs.defaults['CALM_TARGET_DB_GENERATING_NONCALM_LIBRARY_PATH'] = unicode_type('ZZ:||>>>||ZZ:')
prefs.defaults['CALM_TARGET_DB_LAST_CHOSEN_LIBRARY_DIRECTORY'] = unicode_type('ZZ:')

prefs.defaults['CALM_TARGET_DB_MUST_BE_REFRESHED'] = unicode_type("False")

prefs.defaults['CALM_DB_VERSION_METADATA_DB'] = unicode_type(2)

prefs.defaults['CALM_DB_VERSION_UPGRADE_SUPPRESS_INFO_DIALOGS'] = unicode_type("False")
prefs.defaults['CALM_DB_VERSION_UPGRADE_FORCE_UPGRADE'] = unicode_type("False")

prefs.defaults['CALM_DB_VERSION_METADATA_TOOLS_DB'] = unicode_type(2)

prefs.defaults['GUI_LAST_UPDATE_DATETIME_SOURCE'] = unicode_type("Last Saved:   ..NEVER...               Number of 'Checked' Libraries Saved: [0]")
prefs.defaults['GUI_NUMBER_SOURCE_LIBRARIES_LAST_SAVED'] = unicode_type(0)

prefs.defaults['GUI_LAST_UPDATE_DATETIME_TARGET'] = unicode_type('..NEVER...')

prefs.defaults['GUI_TARGET_DB_AGE_MESSAGE_LAST_DISPLAYED'] = unicode_type("2015-12-01")

prefs.defaults['GUI_LAST_CC_GENERATION_DATETIME_TARGET'] = unicode_type('...NEVER...')
prefs.defaults['GUI_LAST_CC_GENERATION_WAS_SUCCESSFUL'] =  unicode_type(0)
prefs.defaults['GUI_LAST_CC_GENERATION_NUMBER_LIBRARIES'] =  unicode_type(0)
prefs.defaults['GUI_LAST_CC_GENERATION_NO_LIBRARIES_TO_GENERATE'] = unicode_type("False")

prefs.defaults['CALM_LAST_CONSOLIDATION_JOB_DATETIME'] = unicode_type('...NEVER...')
prefs.defaults['CALM_LAST_CONSOLIDATION_TARGET_DB_FULL_PATH'] = unicode_type('ZZ:')
prefs.defaults['CALM_LAST_CONSOLIDATION_NUMBER_LIBRARIES'] =  unicode_type(0)
prefs.defaults['CALM_LAST_CONSOLIDATION_NUMBER_BOOKS'] =  unicode_type(0)

prefs.defaults['GUI_METADATA_TOOLS_LAST_SOURCES_DEFRAGMENT_DATETIME'] = unicode_type('...NEVER...')
prefs.defaults['GUI_METADATA_TOOLS_LAST_SOURCES_DEFRAGMENT_COUNT'] = unicode_type(0)

prefs.defaults['GUI_LAST_TAB_USED'] = unicode_type('0')

prefs.defaults['genre'] = unicode_type("#genre_calm")        # owned by the 'Derive Genres' job

prefs.defaults['CALM_MCS_INDEX_CONSOLIDATION'] = unicode_type("False")

class ConfigWidget(QWidget):

    def __init__(self):

        QWidget.__init__(self)

        self.layout_1 = QVBoxLayout()
        self.setLayout(self.layout_1)

        self.layout_1.setSpacing(0)
        self.layout_1.setContentsMargins(QMargins(0,0,0,0));

        self.paths_groupbox = QGroupBox('Preferences')
        self.layout_1.addWidget(self.paths_groupbox)

        self.paths_layout = QGridLayout()
        self.paths_groupbox.setLayout(self.paths_layout)

        font = QFont()

        font.setBold(False)
        font.setPointSize(10)

        self.label1 = QLabel()
        self.label1.setTextFormat(Qt.RichText)
        self.label1.setText("<center><font color='#0404B4'>               Please Customize Directly Within CALM             </font></center>")
        self.label1.setFont(font)
        self.paths_layout.addWidget(self.label1)

        self.resize(self.sizeHint())

    def save_settings(self):
        return
    def validate(self):
        return False

#END of config.py

