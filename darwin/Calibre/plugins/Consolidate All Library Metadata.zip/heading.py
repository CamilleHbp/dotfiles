# -*- coding: utf-8 -*-
__license__   = 'GPL v3'
__copyright__ = '2015,2016,2017,2018,2019,2020,2021,2022,2023 DaltonST'
__my_version__ = "2.0.44"  #Qt.core

#------------------------------------------------------------------------------------------------------
def log_heading_common(log,s1,s2,s3,s4,s5):
    #common heading for jobs in Q&S

    import time
    localtime = time.asctime( time.localtime(time.time()) )
    log(localtime)

    import platform
    log("Python: " + platform.system() + "   " + platform.python_implementation() + "   " + platform.python_version())

    if s1:
        log(s1)       #usually SQLite version

    if s2:              #usually PRAGMA statement
        if s2 == "PRAGMA main.locking_mode=EXCLUSIVE;":
            s2 = "SQLite DB Locking Mode: EXCLUSIVE [GUI Is Locked]"
            log(s2)
            log(" ")
            log("═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════")
        else:
            log(s2)
            log(" ")

    if s3:
        log(s3)        #usually "Beginning ...."

    if s4:
        log(s4)        #optional

    if s5:
        log(s5)        #optional

    log("═════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════")

#END heading.py
