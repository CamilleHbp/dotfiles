# -*- coding: utf-8 -*-
__license__   = 'GPL v3'
__copyright__ = '2015,2016,2017,2018,2019,2020,2021,2022,2023 DaltonST'
__my_version__ = "2.0.46"  # Case-sensitive filesystems, like BTRFS, are now supported.  Qt6 compatibility when resizing columns via the mouse cursor in the list editors for selectively activating custom columns and tag rules.

from calibre.customize import InterfaceActionBase

class ActionBaseConsolidateAllLibraryMetadata(InterfaceActionBase):

    name                    = 'Consolidate All Library Metadata'
    description           = "Consolidate a Snapshot of All Metadata, including Custom Columns, from All of the Books in All of your Libraries for Review, Analysis and Custom Column Standardization using Powerful Tools; Perform Centralized Library Custom Column Metadata Maintenance."
    supported_platforms     = ['windows', 'osx', 'linux']
    author                  = 'DaltonST'
    version                 = (2, 0, 46)
    minimum_calibre_version = (6, 0, 0)

    actual_plugin           = 'calibre_plugins.consolidate_all_library_metadata.ui:ActionConsolidateAllLibraryMetadata'                             # the special .txt file name has the substring "consolidate_all_library_metadata"

    gui_name = 'Consolidate All Library Metadata'

    #--------------------------------------------------------------------------------------------------------------------------
    def initialize(self):
        pass
    #--------------------------------------------------------------------------------------------------------------------------
    def is_customizable(self):
        return True
    #--------------------------------------------------------------------------------------------------------------------------
    def config_widget(self):
        from calibre_plugins.consolidate_all_library_metadata.config import ConfigWidget
        return ConfigWidget()
    #--------------------------------------------------------------------------------------------------------------------------
    def save_settings(self, ConfigWidget):
        ConfigWidget.save_settings()
        ac = self.actual_plugin_
        if ac is not None:
            ac.apply_settings()
    #-------------------------------------------
#~ END of __init__py